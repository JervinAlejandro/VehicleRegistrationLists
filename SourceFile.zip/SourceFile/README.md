# VehicleRegistrationLists
Users can add, delete, edit, and tag reset registration plates using the software. Additionally, the user can save the data to a text file, which the application can open.

Version 1.2
- Fixed Bugs and Errors

Version: 1.1
- Fixed Edit Button

Version: 1.0
- Add Button: Allows the user to add registration plate to the list by typing them into the text field
- Delete Button: Allows user to remove the selected registration plate from the list
- Edit Button: Allow the user to edit the registration plate displayed in the list
- Tag Button: Allows the user to flag a registration plate for future inspection
- Reset Button: Allows the user to erase all registered plates from the list
- Open Button: Allows the user to open saved text file
- Save Button: Allows the user to save the entire list in a text file
